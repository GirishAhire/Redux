
import { BUY_CAKE } from "./cakeTypes" 

// step 3
// const buyCake =() =>{
//     return{
//         // type:'BUY_CAKE'
//         type:BUY_CAKE
//     }
// }


export const buyCake =() =>{
    return{
        // type:'BUY_CAKE'
        type:BUY_CAKE
    }
}