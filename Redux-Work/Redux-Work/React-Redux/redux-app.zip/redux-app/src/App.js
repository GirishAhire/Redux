import logo from './logo.svg';
import './App.css';
import CakeContainer from './components/CakeContainer';

// step 6
import {Provider} from 'react-redux'

// step 8
import {store} from './redux'



function App() {
  return (
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>

    // step 2
    // <div className="App">
    //   <CakeContainer/>
    // </div>



    // step 7
    <Provider store={store}>
    <div className="App">
      <CakeContainer/>
    </div>
    </Provider>










  );
}

export default App;
