//type rfc and then press enter to create functional components.
// step 1
import React from "react";
import { buyCake } from "../redux/cake/cakeActions";

//Step 9-B1
import { connect } from "react-redux";

// const CakeContainer = () => {
//   return (
//     <div>
//       <h2>Number of Cakes</h2>
//       <button>Buy Cake</button>
//     </div>
//   );
// };


//step 10
const CakeContainer = (props) => {
    return (
      <div>
        <h2>Number of Cakes - {props.numOfCakes}</h2>
        <button onClick={props.buyCake}>Buy Cake</button>
      </div>
    );
  };




//Step 9-A

const mapStateToProps = (state) => {
  return {
    numOfCakes: state.numOfCakes,
  };
};

// step 9-B
const mapDispatchToProps = (dispatch) => {
  return {
    buyCake: () => dispatch(buyCake()),
  };
};

// export default CakeContainer;
//step 9-C
export default connect(
    mapStateToProps, 
    mapDispatchToProps
    )(CakeContainer);
